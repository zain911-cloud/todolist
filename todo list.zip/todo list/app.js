// Select DOM elements
const todoInput = document.getElementById('todo-input');
const addButton = document.getElementById('add-button');
const todoList = document.getElementById('todo-list');
const totalTasks = document.getElementById('total-tasks');

// Define an array to store todo items
let todos = [];

// Render todo items on the page
function renderTodos() {
  todoList.innerHTML = '';
  todos.forEach((todo, index) => {
    const li = document.createElement('li');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.id = `todo-${index}`;
    checkbox.checked = todo.completed;
    const label = document.createElement('label');
    label.htmlFor = `todo-${index}`;
    label.textContent = todo.text;
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.addEventListener('click', () => {
      todos.splice(index, 1);
      renderTodos();
    });
    li.appendChild(checkbox);
    li.appendChild(label);
    li.appendChild(deleteButton);
    if (todo.completed) {
      li.classList.add('checked');
    }
    todoList.appendChild(li);
  });
  totalTasks.textContent = `Total tasks: ${todos.length}`;
}

// Add a new todo item to the list
function addTodo() {
  const text = todoInput.value.trim();
  if (text.length) {
    todos.push({ text: text, completed: false });
    todoInput.value = '';
    renderTodos();
  }
}

// Add event listeners
addButton.addEventListener('click', (event) => {
  event.preventDefault();
  addTodo();
});

todoInput.addEventListener('keydown', (event) => {
  if (event.keyCode === 13) {
    event.preventDefault();
    addTodo();
